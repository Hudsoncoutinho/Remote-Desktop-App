package br.estacio.remoteok.controller;

public class UserController {
	
}
