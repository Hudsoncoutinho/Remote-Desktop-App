package br.estacio.remoteok.controller;

import br.estacio.remoteok.model.Job;

import java.util.ArrayList;
import kong.unirest.HttpResponse;
import kong.unirest.JsonNode;
import kong.unirest.Unirest;
import kong.unirest.json.JSONArray;
import kong.unirest.json.JSONObject;

public class JobController {
	// http://kong.github.io/unirest-java/#requests

	// Gett data from API
	public ArrayList<Job> pullApiData(String url) {
		// String url = "https://remoteok.io/api";

		// Getting the API content
		HttpResponse<JsonNode> responseGot = (HttpResponse<JsonNode>) Unirest.get(url).asJson();

		// Converting the content got to an array
		JSONArray jobs = responseGot.getBody().getArray();

		// Careating a new list
		ArrayList<Job> listJobs = new ArrayList<>();

		// Adding from 1 all jobs found to the list careate before
		for (int i = 1; i < jobs.length(); i++) {
			// Taking one job to process
			JSONObject job = jobs.getJSONObject(i);
			
			// Creating a new array list for the tags
			ArrayList<String> tags = new ArrayList<>();
			
			// Getting all the tags from this jSON
			JSONArray tagsArray = job.getJSONArray("tags");
			
			// Adding tags to the tags list array
			for (int j = 0; j < tagsArray.length(); j++) {
				tags.add(tagsArray.getString(j));
			}

			// Adding to the list
			listJobs.add(new Job(job.getInt("id"), job.getString("slug"), job.getString("epoch"), job.getString("company"), job.getString("company_logo"), job.getString("position"), job.getString("date"), tags, job.getString("description"), job.getString("url")));
		}
		return listJobs;
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	public static void main(String[] args) {
		// Getting the API content
		HttpResponse<JsonNode> response = (HttpResponse<JsonNode>) Unirest.get("https://remoteok.io/api").asJson();

		// Converting the content got to an array
		JSONArray jobs = response.getBody().getArray();

		// Careating a new list
		ArrayList<Job> list = new ArrayList<>();

		// Adding from 1 all jobs found to the list careate before
		for (int i = 1; i < jobs.length(); i++) {
			JSONObject job = jobs.getJSONObject(i);

			ArrayList<String> tags = new ArrayList<>();
			JSONArray tagsArray = job.getJSONArray("tags");
			for (int j = 0; j < tagsArray.length(); j++) {
				tags.add(tagsArray.getString(j));
			}
			
			//list.add(new Job(job.getString("slug"), job.getString("id"), job.getString("epoch"), job.getString("date"), job.getString("company"), job.getString("company_logo"), job.getString("position"), null, job.getString("description"), job.getString("url")));
			// list.add(new Job(job.getInt("id"), job.getString("slug"), job.getString("epoch"), job.getString("company"), job.getString("company_logo"), job.getString("position"), job.getString("date"), null, job.getString("logo"), job.getString("description"), job.getString("url")));
			list.add(new Job(job.getInt("id"), job.getString("slug"), job.getString("epoch"), job.getString("company"), job.getString("company_logo"), job.getString("position"), job.getString("date"), tags, job.getString("description"), job.getString("url")));

		}

		// Listing jobs
		for (Job job : list) {
			System.out.println(job.toString());
		}
	}

}
