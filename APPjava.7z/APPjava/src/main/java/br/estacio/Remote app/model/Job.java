package br.estacio.remoteok.model;

import java.util.ArrayList;

public class Job {

	private int id;
	private String slug;
	private String epoch;
	private String company;
	private String companyLogo;
	private String position;
	private String date;
	private ArrayList<String> tags;
	// private String logo;
	private String description;
	private String url;
	private boolean resultText = false;

	public Job(int id, String slug, String epoch, String company, String companyLogo, String position, String date, ArrayList<String> tags, String description, String url) {
		this.id = id;
		this.slug = slug;
		this.epoch = epoch;
		this.company = company;
		this.companyLogo = companyLogo;
		this.position = position;
		this.date = date;
		this.tags = tags;
		// this.logo = logo;
		this.description = description;
		this.url = url;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getSlug() {
		return slug;
	}

	public void setSlug(String slug) {
		this.slug = slug;
	}

	public String getEpoch() {
		return epoch;
	}

	public void setEpoch(String epoch) {
		this.epoch = epoch;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getCompanyLogo() {
		return companyLogo;
	}

	public void setCompanyLogo(String companyLogo) {
		this.companyLogo = companyLogo;
	}

	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public ArrayList<String> getTags() {
		return tags;
	}

	public void setTags(ArrayList<String> tags) {
		this.tags = tags;
	}

//	public String getLogo() {
//		return logo;
//	}
//
//	public void setLogo(String logo) {
//		this.logo = logo;
//	}
	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}
	
	public boolean hasText(String text) {
		if (this.getCompany().toLowerCase().contains(text.toLowerCase())) {
			this.resultText = true;
		}
		if (this.getCompanyLogo().toLowerCase().contains(text.toLowerCase())) {
			this.resultText = true;
		}
		if (this.getDescription().toLowerCase().contains(text.toLowerCase())) {
			this.resultText = true;
		}
		if (this.getEpoch().toLowerCase().contains(text.toLowerCase())) {
			this.resultText = true;
		}
		if (this.getSlug().toLowerCase().contains(text.toLowerCase())) {
			this.resultText = true;
		}
		if (this.getPosition().toLowerCase().contains(text.toLowerCase())) {
			this.resultText = true;
		}
		if (this.getUrl().toLowerCase().contains(text.toLowerCase())) {
			this.resultText = true;
		}
		if (this.getDate().toLowerCase().contains(text.toLowerCase())) {
			this.resultText = true;
		}
		if (this.getTags().toString().toLowerCase().contains(text.toLowerCase())) {
			this.resultText = true;
		}
		return this.resultText;
	}
	

	@Override
	public String toString() {
		// return "Job{" + "id=" + id + ", slug=" + slug + ", epoch=" + epoch + ", company=" + company + ", companyLogo=" + companyLogo + ", position=" + position + ", date=" + date + ", tags=" + tags + ", logo=" + logo + ", description=" + description + ", url=" + url + '}';
		// return "Job{" + "id=" + id + ", slug=" + slug + ", epoch=" + epoch + ", company=" + company + ", companyLogo=" + companyLogo + ", position=" + position + ", date=" + date + ", tags=" + tags + ", description=" + description + ", url=" + url + '}';
		return "\n\nid=" + id + "\nslug=" + slug + "\nepoch=" + epoch + "\ncompany=" + company + "\ncompanyLogo=" + companyLogo + "\nposition=" + position + "\ndate=" + date + "\ntags=" + tags + "\ndescription=" + description + "\nurl=" + url;
	}
}
